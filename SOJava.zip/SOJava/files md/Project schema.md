#SOJava
/SOJava
	/File
	(files of example)
	-pippo.txt
-SOJava.jar

(Done)