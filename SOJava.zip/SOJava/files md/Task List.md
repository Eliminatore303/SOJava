Cose da fare:

1) gestire eccezione/i riguardo apertura di un file con 2 istanze del Note; (Done)
1.1) se file già aperto non faccio riaprire il file con nuova istanza; (Done)
2) sistemazione immagini e file per il .jar (Done)
2.1) immagini devo essere visibili nel progetto una volta esportato (Done)
2.2) impostare le immagini delle finestre quando il file viene esportato (Done)
3) creazione della struttura del progetto (struttura di directory) (Done)
4) ci deve essere la possibilità usare i file tramite la GUI anche se il progetto è compresso (Done)
4.1) verranno solo aperti i file della cartella /File (Done)
4.1.1)  modificare path dei file aperti da explorer e note (Done)
5) sistemazione bug, quando salvo (save not save as..) senza aprire un file non permetterlo (Done)
6) sistemazione in calcolatrice di calcolo di numeri periodici es: 3/7 (Done)
7) ridimensionamento delle finestre; (Done)
8) sistemazione di icona SO;

In futuro:

1) per la calcolatrice utilizzare anche il tastierino numerico e i numeri della tastiera come input; (Done)
2) inserire "a capo automatico" nel Note come opzione;
3) poter gestire i vari file anche in cartelle esterne al progetto;
4) sistemazione del ridimensionamento delle finestre (autoridimensionamento oggetti nelle finestre);
5) inserire altre calcolatrici (unità di misura comprese);
5.1) scegliere il tipo di calolatrice (unità di misure comprese);
6) finire di sitemare l'orologio integrandolo nella finestra principale;
7) inserire calendario;
8) inserire possibile modifica di data/ora;

Opzioni per eventi: KeyListener
Menu per scegliere opzioni del note: JMenuBar + JMenuItem (Con aggiunta di scelta rapida) (Done)
FileChooser per navigare nel file sistem (apertura file) (Done)

