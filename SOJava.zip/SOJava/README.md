# SOJava
If you want to start the file open the SOJava.jar, it is an executable file.
If you don't know how to execute it, go simply to:

https://www.oracle.com/java/technologies/downloads/

Install the .exe for your SO and after simply doble click on the .jar.

All advice is welcome!!